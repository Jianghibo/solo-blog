title: PAT_A1025 PAT Ranking (25 分)
date: '2019-08-06 20:46:50'
updated: '2019-08-07 19:18:07'
tags: [PAT甲级, 算法]
permalink: /articles/2019/08/06/1565095610140.html
---
![](https://img.hacpai.com/bing/20190113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 题目
>* Programming Ability Test (PAT) is organized by the College of Computer Science and Technology of Zhejiang University. Each test is supposed to run simultaneously in several places, and the ranklists will be merged immediately after the test. Now it is your job to write a program to correctly merge all the ranklists and generate the final rank.
>
>* **Input Specification:**
Each input file contains one test case. For each case, the first line contains a positive number N (≤100), the number of test locations. Then N ranklists follow, each starts with a line containing a positive integer K (≤300), the number of testees, and then K lines containing the registration number (a 13-digit number) and the total score of each testee. All the numbers in a line are separated by a space.
>
>* **Output Specification:**
For each test case, first print in one line the total number of testees. Then print the final ranklist in the following format:   
registration_number final_rank location_number local_rank
>* The locations are numbered from 1 to N. The output must be sorted in nondecreasing order of the final ranks. The testees with the same score must have the same rank, and the output must be sorted in nondecreasing order of their registration number;
>* **Sample Input:**
2
5
1234567890001 95
1234567890005 100
1234567890003 95
1234567890002 77
1234567890004 85
4
1234567890013 65
1234567890011 25
1234567890014 100
1234567890012 85
>* **Sample Output:**
9
1234567890005 1 1 1
1234567890014 1 2 1
1234567890001 3 1 2
1234567890003 3 1 2
1234567890004 5 1 4
1234567890012 5 2 2
1234567890002 7 1 5
1234567890013 8 2 3
1234567890011 9 2 4

* **源码参考：**

```c++
#include  <cstdio>
#include  <cstring>
#include  <algorithm>
using  namespace  std;

struct  student
{
    char  r_num[15]; //准考证号
    int score; //分数
    int f_rank; //排名
    int l_num; //考场号
    int l_rank; //本考场排名
}stu[30010];

//sort中的比较函数，使得成绩高的排在前面，成绩相同按照准考证号小号在前
bool  cmp(student stu1,student stu2)
{
    if(stu1.score!=stu2.score)
        return  stu1.score>stu2.score;
    else
        return  strcmp(stu1.r_num,stu2.r_num)<0;
}
int  main()
{
    int n=0; //全部考生数目
    int N;//考场数目
    scanf("%d",&N);
    for(int i=0;i<N;++i)
    {
        int K;//每个考场考生数目
        //int count;
        scanf("%d",&K);
        for(int j=0;j<K;++j)
        {
            scanf("%s  %d",&stu[n].r_num,&stu[n].score);
            stu[n].l_num=i+1;
            ++n;
        }
        //每输入完一个考场的信息后，将本考场的成绩进行排序，记录下本考场排名
        sort(stu[n-K],stu[n],cmp);
        stu[n-K].l_rank=1;
        //名次并列，但不可以影响改变后面一名的成绩
        for(int i=n-K+1;i<n;++i)
        {
            if(stu[i].score==stu[i-1].score)
            {
                stu[i].l_rank=stu[i-1].l_rank;
            }
            else
            {
                stu[i].l_rank=i-(n-K)+1;
            }
        }
        //end每输入...
    }
    //获取完全部输入信息后，将所有的考生的成绩进行排序，记录排名
    sort(stu[0],stu[n],cmp);
    stu[0].f_rank=stu[0].l_rank=1;
    for(int i=1;i<n;++i)
    {
        if(stu[i].score==stu[i-1].score)
        {
            stu[i].f_rank=stu[i-1].f_rank;
        }
        else
        {
            stu[i].f_rank=i+1;
        }
    }
    //end获取完...
    printf("%d\n",n);
    for(int i=0;i<n;++i)
    {
        printf("%s  %d  %d  %d",stu[i].r_num,stu[i].f_rank,stu[i].l_num,stu[i].l_rank;
    }
    return  0;
}
```
