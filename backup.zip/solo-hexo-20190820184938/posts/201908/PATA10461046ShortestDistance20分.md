title: PAT_A1046 1046 Shortest Distance (20 分)
date: '2019-08-07 20:36:52'
updated: '2019-08-07 20:36:52'
tags: [PAT甲级, 算法]
permalink: /articles/2019/08/07/1565181412140.html
---
![](https://img.hacpai.com/bing/20180216.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目
>* The task is really simple: given N exits on a highway which forms a simple cycle, you are supposed to tell the shortest distance between any pair of exits.
>* **Input Specification:**
Each input file contains one test case. For each case, the first line contains an integer N (in $[3,10^5]$), followed by N integer distances $D_1,D_2...D​_N$ , where $D​_i$ is the distance between the $i$-th and the ($i+1$)-st exits, and $D_N$ is between the N-th and the 1st exits. All the numbers in a line are separated by a space. The second line gives a positive integer M ($≤10^4$), with M lines follow, each contains a pair of exit numbers, provided that the exits are numbered from 1 to N. It is guaranteed that the total round trip distance is no more than $10^7$.
>* **Output Specification:**
For each test case, print your results in M lines, each contains the shortest distance between the corresponding given pair of exits.
>* **Sample Input:**
5 1 2 4 14 9
3
1 3
2 5
4 1
>* **Sample Output:**
3
10
7

* **源码参考：**

```cpp
/*
myarr[i]存放从头到i处的距离，myarr[0]存放0；
mydis[i]在开始时存放输入的距离数组，后面用作存放输出的两点间距离；
sum存放距离之和。
*/
#include <cstdio>
#include <iostream>
using namespace std;

const int maxn=100010;
int myarr[maxn],mydis[maxn];
int sum=0;

int main()
{
    int N;
    scanf("%d",&N);
    for(int i=0;i<N;++i)
    {
        scanf("%d",&mydis[i]);
        sum=sum+mydis[i];
        if(i==0)
        {
           myarr[i]=0;
        }
        else
        {
            myarr[i]=myarr[i-1]+mydis[i-1];
        }
    }
    int M;
    scanf("%d",&M);
    int a,b;
    for(int i=0;i<M;++i)
    {
        scanf("%d %d",&a,&b);
        if(a>b)
        {
            mydis[i]=myarr[a-1]-myarr[b-1];
        }
        else
        {
            mydis[i]=myarr[b-1]-myarr[a-1];
        }
        if(mydis[i]>sum-mydis[i])
        {
            mydis[i]=sum-mydis[i];
        }
    }
    for(int i=0;i<M;++i)
    {
        printf("%d\n",mydis[i]);
    }
    return 0;
}
```
