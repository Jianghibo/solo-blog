title: PAT_A1065 A+B and C (64bit) (20 分)
date: '2019-08-07 21:47:47'
updated: '2019-08-07 21:47:47'
tags: [PAT甲级, 算法]
permalink: /articles/2019/08/07/1565185667843.html
---
![](https://img.hacpai.com/bing/20181116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目
>* Given three integers A, B and C in $[−2^{63},2^{63}]$, you are supposed to tell whether $A+B>C$.
>* **Input Specification:**
The first line of the input gives the positive number of test cases, T (≤10). Then T test cases follow, each consists of a single line containing three integers A, B and C, separated by single spaces.
>* **Output Specification:**
For each test case, output in one line `Case #X: true` if A+B>C, or `Case #X: false` otherwise, where X is the case number (starting from 1).
>* **Sample Input:**
3
1 2 3
2 3 4
9223372036854775807 -9223372036854775808 0
>* **Sample Output:**
Case #1: false
Case #2: true
Case #3: false

* **源码参考：**

```cpp
//两个负值相加可能会负溢出成正值，两个正值相加可能会正溢出为负值。
//long long型的存储范围是[-2^63,2^63-1]
#include <cstdio>
#include <iostream>
using namespace std;

int main()
{
    long long a,b,c;
    long long result;
    int T;
    bool flag;
    scanf("%d",&T);
    for(int i=0;i<T;++i)
    {
        scanf("%lld %lld %lld",&a,&b,&c);
        result=a+b;
        if(a>0 && b>0 && result<0)  //rsult<0不用等号,result溢出区间为[-2^63,-2]
            flag=true;
        else if(a<0 && b<0 && result>=0)    //result<=0要用等号，result溢出区间[0,2^63)
            flag=false;
        else if(result>c)
            flag=true;
        else
            flag=false;
            
        if(flag==true)
            printf("Case #%d: true\n",(i+1));
        else
            printf("Case #%d: false\n",(i+1));
    }
    return  0;
}
```
