title: PAT_A1001 A+B Format (20 分)
date: '2019-08-20 19:03:10'
updated: '2019-08-20 19:03:10'
tags: [PAT甲级, 算法]
permalink: /articles/2019/08/20/1566298990212.html
---
![](https://img.hacpai.com/bing/20190318.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目
>* Calculate a+b and output the sum in standard format -- that is, the digits must be separated into groups of three by commas (unless there are less than four digits).
>* **Input Specification:**
Each input file contains one test case. Each case contains a pair of integers a and b where $−10^6
​​ ≤a,b≤10^6$.The numbers are separated by a space.
>* **Output Specification:**
>For each test case, you should output the sum of a and b in one line. The sum must be written in the standard format.
>* **Sample Input:**
`-1000000 9`
>* **Sample Output:**
`-999,991`

* 源码参考：

```cpp
#include <cstdio>
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int a,b;
    int c;
    scanf("%d%d",&a,&b);
    c=a+b;
    int absc=abs(c);
    if(abs(c)>=1000000)
        printf("%d,%03d,%03d",c/1000000,absc%1000000/1000,absc%1000);
    else if(abs(c)>=1000)
        printf("%d,%03d",c/1000,absc%1000);
    else
        printf("%d",c);
    return 0;
}
```

* 源码参考二：

```cpp
#include <cstdio>
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int a,b;
    int c;
    scanf("%d%d",&a,&b);;
    c=a+b;
    int h=0,m=0;
    if(c/1000000!=0)
    {
        h=c/1000000;
        printf("%d,",h);
        c=abs(c%1000000);
    }
    if(c/1000!=0||h!=0)
    {
        m=c/1000;
        if(h!=0)
            printf("%03d,",m);
        else
            printf("%d,",m);
        c=abs(c%1000);
    }
    if(h!=0||m!=0)
        printf("%03d\n",c);
    else
        printf("%d\n",c);
    return 0;
}
```

