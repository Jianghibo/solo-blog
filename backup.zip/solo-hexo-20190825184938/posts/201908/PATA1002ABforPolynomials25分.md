title: PAT_A1002 A+B for Polynomials (25 分)
date: '2019-08-20 18:43:27'
updated: '2019-08-20 18:43:27'
tags: [PAT甲级, 算法]
permalink: /articles/2019/08/20/1566297807247.html
---
![](https://img.hacpai.com/bing/20190527.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目
>* This time, you are supposed to find A+B where A and B are two polynomials.
>* **Input Specification:**
Each input file contains one test case. Each case occupies 2 lines, and each line contains the information of a polynomial:
$K N_1  aN_1 N_2  a​N_​2​​ ... N_K  aN_K$
where K is the number of nonzero terms in the polynomial, $N_i$ and $aN_i(i=1,2,⋯,K)$ are the exponents and coefficients, respectively. It is given that $1≤K≤10,0≤N_K<⋯<N_2<N_1≤1000$.
>* **Output Specification:**
For each test case you should output the sum of A and B in one line, with the same format as the input. Notice that there must be NO extra space at the end of each line. Please be accurate to 1 decimal place.
>* **Sample Input:**
`2 1 2.4 0 3.2`
`2 2 1.5 1 0.5`
>* **Sample Output:**
`3 2 1.5 1 2.9 0 3.2`
* 源码参考

```cpp
#include <cstdio>
#include <iostream>
using namespace std;

const int maxn=1010;
double p[maxn];
int main()
{
    int count=0;
    int K,n;
    scanf("%d",&K);
    for(int i=0;i<K;++i)
    {
        scanf("%d",&n);
        scanf("%lf",&p[n]);
        count++;
    }
    scanf("%d",&K);
    double temp;
    for(int i=0;i<K;++i)
    {
        scanf("%d",&n);
        scanf("%lf",&temp);
        if(p[n]!=0)
        {
            p[n]+=temp;
            if(p[n]==0)
                count--;
        }
        else
        {
            p[n]=temp;
            count++;
        }
    }
    printf("%d",count);
    for(int i=maxn-1;i>=0;i--)
    {
        if(p[i]!=0)
            printf(" %d %.1f",i,p[i]);
    }
    return 0;
}
```

